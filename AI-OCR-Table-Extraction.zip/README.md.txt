# AI-OCR Table Extraction System

This project automatically extracts tables from documents using OCR and AI.

## Tech
- FastAPI
- PaddleOCR/Tesseract
- YOLOv8
- MySQL

## Run
pip install -r requirements.txt
uvicorn backend.main:app --reload
